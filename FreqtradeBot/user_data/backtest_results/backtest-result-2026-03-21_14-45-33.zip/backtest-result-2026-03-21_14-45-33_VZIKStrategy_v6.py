"""
VZIKStrategy v6.0 — "Trend Rider"

Philosophy: Ride established uptrends by entering on pullbacks.
- NO shorts (failed in v5: 41 trades, 0 wins)
- NO trading in bear markets (v4 was right: stay flat)
- Enter on pullbacks to support in confirmed uptrends
- Wider trailing stop to let winners run (v4 killed trades in 6 min)

Key fixes vs v4:
- Pullback entries instead of EMA crossover (which whipsaws in trends)
- Trailing stop: 2.5% trail after 4% profit (v4: 1% after 2.5% = too tight)
- Custom stoploss: starts 1.5x ATR, not 2x (cut losers faster)
- Removed 4h timeframe requirement (killed entries)
- Removed 3-candle volume_increasing filter (too strict)
"""

import numpy as np
import talib.abstract as ta
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from freqtrade.persistence import Trade
from pandas import DataFrame
from datetime import datetime
from functools import reduce


class VZIKStrategy_v6(IStrategy):
    INTERFACE_VERSION = 3

    # --- ROI: Let winners run longer than v4 ---
    minimal_roi = {
        "0": 0.08,      # 8% immediate (v4: 5%)
        "60": 0.05,     # 5% after 1h
        "180": 0.035,   # 3.5% after 3h
        "360": 0.025,   # 2.5% after 6h
        "720": 0.015,   # 1.5% after 12h
        "1440": 0.01,   # 1% after 24h
    }

    # --- Stoploss ---
    stoploss = -0.04
    use_custom_stoploss = True

    # --- Trailing Stop: WIDER than v4 ---
    trailing_stop = True
    trailing_stop_positive = 0.025       # 2.5% trail (v4: 1% = too tight!)
    trailing_stop_positive_offset = 0.04  # Activate after +4% (v4: 2.5%)
    trailing_only_offset_is_reached = True

    # --- General ---
    timeframe = "1h"
    startup_candle_count = 210
    process_only_new_candles = True
    can_short = False  # LONG ONLY

    # --- HyperOpt Parameters ---
    # EMA
    ema_fast = IntParameter(5, 15, default=9, space="buy")
    ema_slow = IntParameter(15, 30, default=21, space="buy")

    # RSI
    rsi_period = IntParameter(10, 20, default=14, space="buy")
    rsi_pullback_low = IntParameter(30, 45, default=38, space="buy")
    rsi_pullback_high = IntParameter(50, 65, default=55, space="buy")
    rsi_bounce = IntParameter(25, 35, default=30, space="buy")
    rsi_exit = IntParameter(72, 85, default=78, space="sell")

    # ADX
    adx_threshold = IntParameter(18, 30, default=22, space="buy")

    # Volume
    volume_factor = DecimalParameter(0.8, 2.0, default=1.1, space="buy")

    # Leverage
    leverage_long = IntParameter(2, 5, default=3, space="buy")

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        return min(float(self.leverage_long.value), max_leverage)

    def custom_stake_amount(self, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake: float, max_stake: float,
                            leverage: float, entry_tag: str, side: str,
                            **kwargs) -> float:
        # No trading in bear market — return 0 won't open trade
        # This is a safety net; signals should not fire in bear
        return proposed_stake

    def informative_pairs(self):
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # === EMAs ===
        for period in [9, 12, 15, 21, 26, 30]:
            dataframe[f"ema_{period}"] = ta.EMA(dataframe, timeperiod=period)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["ema_200"] = ta.EMA(dataframe, timeperiod=200)

        # === RSI ===
        for period in range(10, 21):
            dataframe[f"rsi_{period}"] = ta.RSI(dataframe, timeperiod=period)

        # === ADX + DI ===
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=14)
        dataframe["plus_di"] = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe["minus_di"] = ta.MINUS_DI(dataframe, timeperiod=14)

        # === MACD ===
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe["macd"] = macd["macd"]
        dataframe["macdsignal"] = macd["macdsignal"]
        dataframe["macdhist"] = macd["macdhist"]

        # === Bollinger Bands ===
        bb = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe["bb_upper"] = bb["upperband"]
        dataframe["bb_middle"] = bb["middleband"]
        dataframe["bb_lower"] = bb["lowerband"]

        # === ATR ===
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["atr_pct"] = dataframe["atr"] / dataframe["close"]

        # === Volume ===
        dataframe["volume_ema"] = ta.EMA(dataframe["volume"], timeperiod=20)
        dataframe["volume_ratio"] = dataframe["volume"] / dataframe["volume_ema"]

        # === OBV ===
        dataframe["obv"] = ta.OBV(dataframe)
        dataframe["obv_ema"] = ta.EMA(dataframe["obv"], timeperiod=20)

        # === Regime Detection (simple, 1h only) ===
        dataframe["is_bull"] = (
            (dataframe["close"] > dataframe["ema_200"]) &
            (dataframe["ema_50"] > dataframe["ema_200"])
        ).astype(int)

        dataframe["is_bear"] = (
            (dataframe["close"] < dataframe["ema_200"]) &
            (dataframe["ema_50"] < dataframe["ema_200"])
        ).astype(int)

        # Pullback zone: price near EMA21 in uptrend
        ema_slow_val = f"ema_{self.ema_slow.value}"
        if ema_slow_val in dataframe.columns:
            dataframe["near_ema_support"] = (
                (dataframe["low"] <= dataframe[ema_slow_val] * 1.015) &
                (dataframe["close"] > dataframe[ema_slow_val] * 0.99)
            ).astype(int)
        else:
            dataframe["near_ema_support"] = 0

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        ema_fast = f"ema_{self.ema_fast.value}"
        ema_slow = f"ema_{self.ema_slow.value}"
        rsi = f"rsi_{self.rsi_period.value}"

        # === LONG 1: Trend Pullback (main signal) ===
        # Enter when price pulls back to support in established uptrend
        conditions_pullback = [
            dataframe["is_bull"] == 1,                                    # Confirmed uptrend
            dataframe["near_ema_support"] == 1,                           # Price near EMA support
            dataframe[rsi] > self.rsi_pullback_low.value,                 # RSI not oversold
            dataframe[rsi] < self.rsi_pullback_high.value,                # RSI not overbought
            dataframe["adx"] > self.adx_threshold.value,                  # Trending
            dataframe["volume_ratio"] > self.volume_factor.value,         # Volume confirm
            dataframe["obv"] > dataframe["obv_ema"],                     # OBV positive
            dataframe["macdhist"] > dataframe["macdhist"].shift(1),      # MACD improving
            dataframe["volume"] > 0,
        ]

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_pullback),
            ["enter_long", "enter_tag"]
        ] = (1, "trend_pullback")

        # === LONG 2: RSI Bounce in Uptrend ===
        # Classic oversold bounce, but only in uptrend
        conditions_rsi = [
            dataframe["close"] > dataframe["ema_200"],                    # Above EMA200
            dataframe[rsi].shift(1) < self.rsi_bounce.value,             # Was oversold
            dataframe[rsi] > self.rsi_bounce.value,                       # Now bouncing
            dataframe["close"] > dataframe["bb_lower"],                   # Above BB lower
            dataframe["volume_ratio"] > 0.8,                              # Some volume
            dataframe["obv"] > dataframe["obv_ema"],                     # OBV positive
            dataframe["volume"] > 0,
        ]

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_rsi),
            ["enter_long", "enter_tag"]
        ] = (1, "rsi_bounce")

        # === LONG 3: BB Support Bounce ===
        # Price bounces off lower BB in bull market
        conditions_bb = [
            dataframe["is_bull"] == 1,                                    # Bull market
            dataframe["low"] <= dataframe["bb_lower"] * 1.005,           # Touched BB lower
            dataframe["close"] > dataframe["bb_lower"],                   # Closed above
            dataframe[rsi] < 45,                                          # Not overbought
            dataframe[rsi] > 25,                                          # Not extremely oversold
            dataframe["adx"] > 18,                                        # Some trend
            dataframe["volume_ratio"] > 1.0,                              # Volume confirm
            dataframe["volume"] > 0,
        ]

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_bb),
            ["enter_long", "enter_tag"]
        ] = (1, "bb_bounce")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        rsi = f"rsi_{self.rsi_period.value}"
        ema_fast = f"ema_{self.ema_fast.value}"
        ema_slow = f"ema_{self.ema_slow.value}"

        # === EXIT 1: RSI Overbought ===
        conditions_rsi_exit = [
            dataframe[rsi] > self.rsi_exit.value,
            dataframe["volume"] > 0,
        ]

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_rsi_exit),
            ["exit_long", "exit_tag"]
        ] = (1, "rsi_overbought")

        # === EXIT 2: Bearish EMA Cross + Confirmation ===
        conditions_ema_exit = [
            dataframe[ema_fast] < dataframe[ema_slow],
            dataframe[ema_fast].shift(1) >= dataframe[ema_slow].shift(1),  # Cross happened
            dataframe[rsi] > 55,                                            # Confirm: was high
            dataframe["macdhist"] < 0,                                      # MACD bearish
            dataframe["volume"] > 0,
        ]

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_ema_exit),
            ["exit_long", "exit_tag"]
        ] = (1, "ema_cross_exit")

        # === EXIT 3: BB Upper Touch with High RSI ===
        conditions_bb_exit = [
            dataframe["high"] >= dataframe["bb_upper"],
            dataframe[rsi] > 70,
            dataframe["volume"] > 0,
        ]

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_bb_exit),
            ["exit_long", "exit_tag"]
        ] = (1, "bb_upper_exit")

        return dataframe

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, after_fill: bool,
                        **kwargs) -> float:
        """
        ATR-based dynamic stoploss.
        Starts at 1.5x ATR, tightens as profit grows.
        Key fix: tighter initial stop than v4 (1.5x vs 2x) to cut losers faster.
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(dataframe) < 1:
            return self.stoploss

        last_candle = dataframe.iloc[-1]
        atr = last_candle.get("atr", 0)

        if atr == 0 or current_rate == 0:
            return self.stoploss

        # Dynamic ATR stoploss — tightens with profit
        if current_profit > 0.04:
            atr_mult = 0.5  # Very tight at +4%
        elif current_profit > 0.025:
            atr_mult = 0.8  # Tight at +2.5%
        elif current_profit > 0.015:
            atr_mult = 1.0  # Medium at +1.5%
        elif current_profit > 0.005:
            atr_mult = 1.2  # Slightly tighter at +0.5%
        else:
            atr_mult = 1.5  # Default: 1.5x ATR (v4: 2.0x)

        atr_stoploss = -(atr_mult * atr) / current_rate

        # Clamp to reasonable range
        atr_stoploss = max(atr_stoploss, -0.045)  # Max 4.5% loss
        atr_stoploss = min(atr_stoploss, -0.008)  # Min 0.8% distance

        return atr_stoploss
